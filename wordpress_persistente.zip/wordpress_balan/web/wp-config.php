<?php
define('DB_NAME', 'wordpressdb');
define('DB_USER', 'advo');
define('DB_PASSWORD', 'Asdqwe123');
define('DB_HOST', 'proxysql:6033');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

$table_prefix = 'wp_';

define('WP_DEBUG', false);

if (!defined('ABSPATH'))
    define('ABSPATH', dirname(__FILE__) . '/');

require_once(ABSPATH . 'wp-settings.php');
