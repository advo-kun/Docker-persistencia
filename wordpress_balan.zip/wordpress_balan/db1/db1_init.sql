CREATE DATABASE IF NOT EXISTS wordpressdb;
USE wordpressdb;

-- Manejar la existencia del usuario 'advo'
DROP USER IF EXISTS 'advo'@'%';
CREATE USER 'advo'@'%' IDENTIFIED BY 'Asdqwe123';
GRANT ALL PRIVILEGES ON wordpressdb.* TO 'advo'@'%';
FLUSH PRIVILEGES;

-- Crear el usuario 'monitor'
DROP USER IF EXISTS 'monitor'@'%';
CREATE USER 'monitor'@'%' IDENTIFIED BY 'monitor';
GRANT REPLICATION CLIENT ON *.* TO 'monitor'@'%';
FLUSH PRIVILEGES;
